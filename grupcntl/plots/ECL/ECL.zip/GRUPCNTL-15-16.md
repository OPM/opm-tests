
### GRUPCNTL-15 Description and Results

[GRUPCNTL-15 Results](plots/GRUPCNTL-15.md) 

![](plots/GRUPCNTL-15-Field_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-15-Group_MANI_A_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-15-Group_MANI_B_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-15-Group_PROD_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-15-Well_PRO3D_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-15-Well_PROD1_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-15-Well_PROD1_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-15-Well_PROD1_Production_Performance.png)
![](plots/GRUPCNTL-15-Well_PROD2_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-15-Well_PROD2_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-15-Well_PROD2_Production_Performance.png)
![](plots/GRUPCNTL-15-Well_PROD3_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-15-Well_PROD3_Production_Performance.png)
![](plots/GRUPCNTL-15-Well_PROD4_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-15-Well_PROD4_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-15-Well_PROD4_Production_Performance.png)

### GRUPCNTL-16 Description and Results

[GRUPCNTL-16 Results](plots/GRUPCNTL-16.md) 

![](plots/GRUPCNTL-16-Field_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-16-Group_MANI_A_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-16-Group_MANI_B_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-16-Group_PROD_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-16-Well_PRO3D_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-16-Well_PROD1_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-16-Well_PROD1_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-16-Well_PROD1_Production_Performance.png)
![](plots/GRUPCNTL-16-Well_PROD2_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-16-Well_PROD2_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-16-Well_PROD2_Production_Performance.png)
![](plots/GRUPCNTL-16-Well_PROD3_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-16-Well_PROD3_Production_Performance.png)
![](plots/GRUPCNTL-16-Well_PROD4_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-16-Well_PROD4_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-16-Well_PROD4_Production_Performance.png)
