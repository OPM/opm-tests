#### GRUPCNTL-03

![](GRUPCNTL-03-Field_Production_Comparison_Plot.png)
![](GRUPCNTL-03-Field_Water_Injection_Comparison_Plot.png)
![](GRUPCNTL-03-Group_INJE_Water_Injection_Comparison_Plot.png)
![](GRUPCNTL-03-Group_PROD_Production_Comparison_Plot.png)
![](GRUPCNTL-03-Group_WGRP1_Production_Comparison_Plot.png)
![](GRUPCNTL-03-Group_WGRP2_Production_Comparison_Plot.png)
![](GRUPCNTL-03-Well_INJ1_Water_Injection_Performance.png)
![](GRUPCNTL-03-Well_PROD1_Production_Performance.png)
![](GRUPCNTL-03-Well_PROD2_Production_Performance.png)
![](GRUPCNTL-03-Well_PROD3_Production_Performance.png)
