
### GRUPCNTL-09 Description and Results

[GRUPCNTL-09 Results](plots/GRUPCNTL-09.md) 

![](plots/GRUPCNTL-09-Field_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-09-Group_PROD_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-09-Well_PROD1_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-09-Well_PROD1_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-09-Well_PROD1_Production_Performance.png)
![](plots/GRUPCNTL-09-Well_PROD2_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-09-Well_PROD2_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-09-Well_PROD2_Production_Performance.png)
![](plots/GRUPCNTL-09-Well_PROD3_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-09-Well_PROD3_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-09-Well_PROD3_Production_Performance.png)
![](plots/GRUPCNTL-09-Well_PROD4_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-09-Well_PROD4_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-09-Well_PROD4_Production_Performance.png)

### GRUPCNTL-10 Description and Results

[GRUPCNTL-10 Results](plots/GRUPCNTL-10.md) 

![](plots/GRUPCNTL-10-Field_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-10-Group_PROD_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-10-Well_PROD1_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-10-Well_PROD1_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-10-Well_PROD1_Production_Performance.png)
![](plots/GRUPCNTL-10-Well_PROD2_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-10-Well_PROD2_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-10-Well_PROD2_Production_Performance.png)
![](plots/GRUPCNTL-10-Well_PROD3_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-10-Well_PROD3_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-10-Well_PROD3_Production_Performance.png)
![](plots/GRUPCNTL-10-Well_PROD4_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-10-Well_PROD4_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-10-Well_PROD4_Production_Performance.png)

### GRUPCNTL-11 Description and Results

[GRUPCNTL-11 Results](plots/GRUPCNTL-11.md) 

![](plots/GRUPCNTL-11-Field_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-11-Group_PROD_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-11-Well_PROD1_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-11-Well_PROD1_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-11-Well_PROD1_Production_Performance.png)
![](plots/GRUPCNTL-11-Well_PROD2_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-11-Well_PROD2_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-11-Well_PROD2_Production_Performance.png)
![](plots/GRUPCNTL-11-Well_PROD3_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-11-Well_PROD3_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-11-Well_PROD3_Production_Performance.png)
![](plots/GRUPCNTL-11-Well_PROD4_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-11-Well_PROD4_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-11-Well_PROD4_Production_Performance.png)

### GRUPCNTL-12 Description and Results

[GRUPCNTL-12 Results](plots/GRUPCNTL-12.md) 

![](plots/GRUPCNTL-12-Field_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-12-Group_PROD_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-12-Well_PROD1_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-12-Well_PROD1_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-12-Well_PROD1_Production_Performance.png)
![](plots/GRUPCNTL-12-Well_PROD2_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-12-Well_PROD2_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-12-Well_PROD2_Production_Performance.png)
![](plots/GRUPCNTL-12-Well_PROD3_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-12-Well_PROD3_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-12-Well_PROD3_Production_Performance.png)
![](plots/GRUPCNTL-12-Well_PROD4_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-12-Well_PROD4_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-12-Well_PROD4_Production_Performance.png)

### GRUPCNTL-13 Description and Results

[GRUPCNTL-13 Results](plots/GRUPCNTL-13.md) 

![](plots/GRUPCNTL-13-Field_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-13-Group_PROD_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-13-Well_PROD1_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-13-Well_PROD1_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-13-Well_PROD1_Production_Performance.png)
![](plots/GRUPCNTL-13-Well_PROD2_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-13-Well_PROD2_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-13-Well_PROD2_Production_Performance.png)
![](plots/GRUPCNTL-13-Well_PROD3_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-13-Well_PROD3_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-13-Well_PROD3_Production_Performance.png)
![](plots/GRUPCNTL-13-Well_PROD4_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-13-Well_PROD4_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-13-Well_PROD4_Production_Performance.png)

### GRUPCNTL-14 Description and Results

[GRUPCNTL-14 Results](plots/GRUPCNTL-14.md) 

![](plots/GRUPCNTL-14-Field_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-14-Group_PROD_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-14-Well_PROD1_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-14-Well_PROD1_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-14-Well_PROD1_Production_Performance.png)
![](plots/GRUPCNTL-14-Well_PROD2_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-14-Well_PROD2_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-14-Well_PROD2_Production_Performance.png)
![](plots/GRUPCNTL-14-Well_PROD3_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-14-Well_PROD3_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-14-Well_PROD3_Production_Performance.png)
![](plots/GRUPCNTL-14-Well_PROD4_Pressure_Comparison_Plot.png)
![](plots/GRUPCNTL-14-Well_PROD4_Production_and_Mode_of_Control_Plot.png)
![](plots/GRUPCNTL-14-Well_PROD4_Production_Performance.png)
