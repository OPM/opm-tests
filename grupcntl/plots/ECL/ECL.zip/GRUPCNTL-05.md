#### GRUPCNTL-05

![](GRUPCNTL-05-Field_Production_Comparison_Plot.png)
![](GRUPCNTL-05-Field_Water_Injection_Comparison_Plot.png)
![](GRUPCNTL-05-Group_INJE_Water_Injection_Comparison_Plot.png)
![](GRUPCNTL-05-Group_PROD_Production_Comparison_Plot.png)
![](GRUPCNTL-05-Group_WGRP1_Production_Comparison_Plot.png)
![](GRUPCNTL-05-Group_WGRP2_Production_Comparison_Plot.png)
![](GRUPCNTL-05-Well_INJ1_Water_Injection_Performance.png)
![](GRUPCNTL-05-Well_PROD1_Production_Performance.png)
![](GRUPCNTL-05-Well_PROD2_Production_Performance.png)
![](GRUPCNTL-05-Well_PROD3_Production_Performance.png)
