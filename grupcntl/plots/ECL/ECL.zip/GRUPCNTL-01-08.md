
### GRUPCNTL-01 Description and Results

[GRUPCNTL-01 Results](plots/GRUPCNTL-01.md) 

![](plots/GRUPCNTL-01-Field_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-01-Field_Water_Injection_Comparison_Plot.png)
![](plots/GRUPCNTL-01-Group_INJE_Water_Injection_Comparison_Plot.png)
![](plots/GRUPCNTL-01-Group_PROD_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-01-Group_WGRP1_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-01-Group_WGRP2_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-01-Well_INJ1_Water_Injection_Performance.png)
![](plots/GRUPCNTL-01-Well_PROD1_Production_Performance.png)
![](plots/GRUPCNTL-01-Well_PROD2_Production_Performance.png)
![](plots/GRUPCNTL-01-Well_PROD3_Production_Performance.png)

### GRUPCNTL-02 Description and Results

[GRUPCNTL-02 Results](plots/GRUPCNTL-02.md) 

![](plots/GRUPCNTL-02-Field_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-02-Field_Water_Injection_Comparison_Plot.png)
![](plots/GRUPCNTL-02-Group_INJE_Water_Injection_Comparison_Plot.png)
![](plots/GRUPCNTL-02-Group_PROD_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-02-Group_WGRP1_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-02-Group_WGRP2_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-02-Well_INJ1_Water_Injection_Performance.png)
![](plots/GRUPCNTL-02-Well_PROD1_Production_Performance.png)
![](plots/GRUPCNTL-02-Well_PROD2_Production_Performance.png)
![](plots/GRUPCNTL-02-Well_PROD3_Production_Performance.png)

### GRUPCNTL-03 Description and Results

[GRUPCNTL-03 Results](plots/GRUPCNTL-03.md) 

![](plots/GRUPCNTL-03-Field_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-03-Field_Water_Injection_Comparison_Plot.png)
![](plots/GRUPCNTL-03-Group_INJE_Water_Injection_Comparison_Plot.png)
![](plots/GRUPCNTL-03-Group_PROD_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-03-Group_WGRP1_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-03-Group_WGRP2_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-03-Well_INJ1_Water_Injection_Performance.png)
![](plots/GRUPCNTL-03-Well_PROD1_Production_Performance.png)
![](plots/GRUPCNTL-03-Well_PROD2_Production_Performance.png)
![](plots/GRUPCNTL-03-Well_PROD3_Production_Performance.png)

### GRUPCNTL-04 Description and Results

[GRUPCNTL-04 Results](plots/GRUPCNTL-04.md) 

![](plots/GRUPCNTL-04-Field_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-04-Field_Water_Injection_Comparison_Plot.png)
![](plots/GRUPCNTL-04-Group_INJE_Water_Injection_Comparison_Plot.png)
![](plots/GRUPCNTL-04-Group_PROD_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-04-Group_WGRP1_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-04-Group_WGRP2_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-04-Well_INJ1_Water_Injection_Performance.png)
![](plots/GRUPCNTL-04-Well_PROD1_Production_Performance.png)
![](plots/GRUPCNTL-04-Well_PROD2_Production_Performance.png)
![](plots/GRUPCNTL-04-Well_PROD3_Production_Performance.png)

### GRUPCNTL-05 Description and Results

[GRUPCNTL-05 Results](plots/GRUPCNTL-05.md) 

![](plots/GRUPCNTL-05-Field_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-05-Field_Water_Injection_Comparison_Plot.png)
![](plots/GRUPCNTL-05-Group_INJE_Water_Injection_Comparison_Plot.png)
![](plots/GRUPCNTL-05-Group_PROD_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-05-Group_WGRP1_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-05-Group_WGRP2_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-05-Well_INJ1_Water_Injection_Performance.png)
![](plots/GRUPCNTL-05-Well_PROD1_Production_Performance.png)
![](plots/GRUPCNTL-05-Well_PROD2_Production_Performance.png)
![](plots/GRUPCNTL-05-Well_PROD3_Production_Performance.png)

### GRUPCNTL-06 Description and Results

[GRUPCNTL-06 Results](plots/GRUPCNTL-06.md) 

![](plots/GRUPCNTL-06-Field_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-06-Field_Water_Injection_Comparison_Plot.png)
![](plots/GRUPCNTL-06-Group_INJE_Water_Injection_Comparison_Plot.png)
![](plots/GRUPCNTL-06-Group_PROD_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-06-Group_WGRP1_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-06-Group_WGRP2_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-06-Well_INJ1_Water_Injection_Performance.png)
![](plots/GRUPCNTL-06-Well_PROD1_Production_Performance.png)
![](plots/GRUPCNTL-06-Well_PROD2_Production_Performance.png)
![](plots/GRUPCNTL-06-Well_PROD3_Production_Performance.png)

### GRUPCNTL-07 Description and Results

[GRUPCNTL-07 Results](plots/GRUPCNTL-07.md) 

![](plots/GRUPCNTL-07-Field_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-07-Field_Water_Injection_Comparison_Plot.png)
![](plots/GRUPCNTL-07-Group_INJE_Water_Injection_Comparison_Plot.png)
![](plots/GRUPCNTL-07-Group_PROD_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-07-Group_WGRP1_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-07-Group_WGRP2_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-07-Well_INJ1_Water_Injection_Performance.png)
![](plots/GRUPCNTL-07-Well_PROD1_Production_Performance.png)
![](plots/GRUPCNTL-07-Well_PROD2_Production_Performance.png)
![](plots/GRUPCNTL-07-Well_PROD3_Production_Performance.png)

### GRUPCNTL-08 Description and Results

[GRUPCNTL-08 Results](plots/GRUPCNTL-08.md) 

![](plots/GRUPCNTL-08-Field_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-08-Field_Water_Injection_Comparison_Plot.png)
![](plots/GRUPCNTL-08-Group_INJE_Water_Injection_Comparison_Plot.png)
![](plots/GRUPCNTL-08-Group_PROD_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-08-Group_WGRP1_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-08-Group_WGRP2_Production_Comparison_Plot.png)
![](plots/GRUPCNTL-08-Well_INJ1_Water_Injection_Performance.png)
![](plots/GRUPCNTL-08-Well_PROD1_Production_Performance.png)
![](plots/GRUPCNTL-08-Well_PROD2_Production_Performance.png)
![](plots/GRUPCNTL-08-Well_PROD3_Production_Performance.png)
