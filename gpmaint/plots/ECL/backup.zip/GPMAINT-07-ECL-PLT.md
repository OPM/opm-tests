#### GPMAINT-07-ECL PLT Results

![](PLT/GPMAINT-07-ECL-Field_Gas_Injection_Performance.png)
![](PLT/GPMAINT-07-ECL-Field_Oil_Injection_Performance.png)
![](PLT/GPMAINT-07-ECL-Field_Production_Performance.png)
![](PLT/GPMAINT-07-ECL-Field_Water_Injection_Performance.png)
![](PLT/GPMAINT-07-ECL-Region_Performance_Plot_Area_Region_1.png)
![](PLT/GPMAINT-07-ECL-Region_Performance_Plot_Area_Region_2.png)
![](PLT/GPMAINT-07-ECL-Region_Performance_Plot_Area_Region_3.png)
![](PLT/GPMAINT-07-ECL-Region_Performance_Plot_Area_Region_4.png)
![](PLT/GPMAINT-07-ECL-Region_Performance_Plot_Area_Region_5.png)
![](PLT/GPMAINT-07-ECL-Region_Performance_Plot_Area_Region_6.png)
![](PLT/GPMAINT-07-ECL-Region_Performance_Plot_FIPNUM_Region_1.png)
![](PLT/GPMAINT-07-ECL-Region_Performance_Plot_FIPNUM_Region_2.png)
